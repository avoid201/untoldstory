# Individual Tiles for Untold Story

## 📊 Statistics
- **Total Tiles:** 536
- **Categories:** 7

## 📁 Structure
```
individual_tiles/
├── terrain/     (32 tiles)
├── objects/     (256 tiles)
├── water/       (64 tiles)
├── building/    (96 tiles)
├── interior/    (48 tiles)
├── ui/          (16 tiles)
├── special/     (24 tiles)
├── tile_info.json
├── statistics.json
└── README.md
```

## 🎮 File Format
- **Naming:** `[ID]_[description].png`
- **Example:** `0001_grass_light.png`
- **Size:** All tiles are 16x16 pixels
- **Format:** PNG with transparency support

## 🛠️ Usage with Tiled

### Import as Collection
1. In Tiled, go to **Map → Add External Tileset**
2. Choose **Collection of Images**
3. Select all tiles from a category folder
4. Set tile size to 16x16

### Import Individual Tiles
1. Drag and drop tiles directly onto your map
2. Use the tile_info.json for reference

## 📝 Tile Categories

### Terrain
- Grass variations (light, dark, forest, etc.)
- Dirt and earth tiles
- Stone and rock surfaces
- Sand and beach tiles

### Water
- Animated water frames (4 frames)
- Shore tiles (all directions)
- Corner pieces for smooth transitions

### Objects
- Trees (oak, pine, dead)
- Bushes and plants
- Rocks and stones
- Flowers and decorations

### Building
- Roof tiles (red, blue, green)
- Wall types (brick, stone, wood)
- Doors and windows

### Interior
- Floor types (wood, tile)
- Furniture (table, chair, bed, bookshelf)
- Carpets and rugs

### UI
- Button states (normal, hover, pressed)
- Icons for game interface

### Special
- Gems (6 colors)
- Keys (gold, silver, bronze)
- Potions (health, mana, stamina)
- Decorative elements

## 🔧 Metadata

The `tile_info.json` file contains detailed information for each tile:
- ID: Unique identifier
- Name: Descriptive name
- Category: Tile category
- Position: Original position in tileset
- Source: Source tileset name

## 💡 Tips

- Use the ID for programmatic reference
- Use the name for human-readable identification
- Categories help organize your tileset library
- All tiles maintain transparency where applicable

---
Created with the Untold Story Tileset Processor
